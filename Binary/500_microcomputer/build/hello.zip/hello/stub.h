#ifndef _STUB_H_INCLUDED_
#define _STUB_H_INCLUDED_

void set_debug_traps();
void force_break();

#endif

/*
 * timer-exec <seconds> <signal> <uid> <gid> <dir> <command> [<arg0>...]
 *
 * Example:
 * timer-exec 3 2 1001 1001 /home/user print-argv print-argv abc def
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <signal.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/socket.h>
#include <netinet/in.h>

/* #define HANDOVER_ENVVAL */
/* #define NO_CHANGE_ROOTDIR */
/* #define NO_CHANGE_USER */

typedef struct {
  int uid;
  int gid;
  char *dir;
  char *command;
  int argc;
  char **argv;
  char **envp;
} param_t;

static int writestr(int s, char *buf)
{
  write(s, buf, strlen(buf));
  return 0;
}

static int command_exec(param_t *p)
{
  if (chdir(p->dir) < 0) {
    writestr(1, "fail chdir.\n");
    _exit(1);
  }

#ifndef NO_CHANGE_ROOTDIR
  if (chroot(".") < 0) {
    writestr(1, "fail chroot.\n");
    _exit(1);
  }

  if (chdir("/") < 0) {
    writestr(1, "fail chdir.\n");
    _exit(1);
  }
#endif

#ifndef NO_CHANGE_USER
  if (setgid(p->gid) < 0) {
    writestr(1, "fail setgid.\n");
    _exit(1);
  }

  if (setuid(p->uid) < 0) {
    writestr(1, "fail setuid.\n");
    _exit(1);
  }
#endif

  if (execve(p->command, p->argv, p->envp) < 0) {
    writestr(1, "fail exec.\n");
    _exit(1);
  }

  return 0;
}

static int timer_proc(param_t *p)
{
  int pid;

  pid = fork();
  if (pid < 0) {
    writestr(1, "fail fork.\n");
    exit(1);
  }
  if (pid) { /* parent */
    return pid;
  }

  /* child process */

  command_exec(p);
  _exit(0);
}

static volatile int finished = 0;

static void sigchld_handler(int val)
{
  int status;
  wait(&status);
  finished = 1;
}

static int timer_main(int sec, int sig, param_t *p)
{
  int pid;

  signal(SIGCHLD, sigchld_handler);

  pid = timer_proc(p);
  if (pid == 0)
    return -1;

  sleep(sec);
  kill(pid, sig);

  while (!finished) {
    sleep(1);
  }

  return 0;
}

static int help()
{
  fprintf(stderr, "timer-exec <seconds> <signal> <uid> <gid> <dir> <command> [<arg0>...]\n");
  exit(1);
}

int main(int argc, char *argv[], char *envp[])
{
  int sec, sig, uid;
  param_t param;
#ifndef HANDOVER_ENVVAL
  char *null_args[] = { NULL };
#endif

  uid = getuid();
#if !defined(NO_CHANGE_ROOTDIR) || !defined(NO_CHANGE_USER)
  if (uid != 0) {
    fprintf(stderr, "You need execute this program as root.\n");
    exit(1);
  }
#endif

  if (argc < 7) {
    help();
  }
  argc--; argv++;

  sec           = atoi(*argv); argc--; argv++;
  sig           = atoi(*argv); argc--; argv++;
  param.uid     = atoi(*argv); argc--; argv++;
  param.gid     = atoi(*argv); argc--; argv++;
  param.dir     = *argv;       argc--; argv++;
  param.command = *argv;       argc--; argv++;
  param.argc = argc;
  param.argv = argv;

#ifdef HANDOVER_ENVVAL
  param.envp = envp;
#else
  param.envp = null_args;
#endif

  if (sig == 0) sig = SIGINT;

  timer_main(sec, sig, &param);

  return 0;
}
